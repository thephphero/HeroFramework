<?php
/**
 * Created by PhpStorm.
 * User: uid20214
 * Date: 22.01.2019
 * Time: 14:37
 */

namespace Bundles\SecurityBundle\DependencyInjection\Compiler;

use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class EntryPointPass implements CompilerPassInterface{

    public function process(ContainerBuilder $container)
    {
        // TODO: Implement process() method.
    }
}